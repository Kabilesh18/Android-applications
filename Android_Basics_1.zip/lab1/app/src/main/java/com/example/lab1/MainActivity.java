package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView t;
    Button b1,b2;
    int font = 30;
    int ch = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t = (TextView) findViewById(R.id.t);
        b1 = (Button)findViewById(R.id.b1);
        b2 = (Button)findViewById(R.id.b2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.setTextSize(font);
                font+=5;
                if(font == 50){
                    font =30;
                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (ch){
                    case 1:
                        t.setTextColor(Color.BLUE);
                        break;
                    case 2:
                        t.setTextColor(Color.RED);
                        break;
                    case 3:
                        t.setTextColor(Color.GREEN);
                        break;
                    case 4:
                        t.setTextColor(Color.CYAN);
                        break;
                    case 5:
                        t.setTextColor(Color.GRAY);
                        break;
                    case 6:
                        t.setTextColor(Color.BLACK);
                        break;
                }
                ch++;
                if(ch == 7){
                    ch = 1;
                }
            }
        });
    }
}