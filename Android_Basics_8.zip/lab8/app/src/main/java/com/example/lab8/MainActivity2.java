package com.example.lab8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity2 extends AppCompatActivity {
    WebView w;
    String lat, lon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        w = (WebView) findViewById(R.id.w);
        Bundle b = getIntent().getExtras();
        lat = b.getString("e1");
        lon = b.getString("e2");
        w.setWebViewClient(new WebViewClient());
        w.getSettings().setJavaScriptEnabled(true);
        String url = "https://google.com/maps/search/?api=1&query="+lat+","+lon;
        w.loadUrl(url);
    }
}