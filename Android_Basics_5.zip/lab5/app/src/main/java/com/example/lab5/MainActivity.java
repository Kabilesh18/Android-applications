package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2,e3;
    SQLiteDatabase db;
    String f1,l1,em;
    Button add,close,show;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = openOrCreateDatabase("Practise",MODE_PRIVATE,null);
        db.execSQL("CREATE TABLE IF NOT EXISTS student(fname VARCHAR, lname VARCHAR, email VARCHAR);");
        add = (Button) findViewById(R.id.b1);
        close = (Button) findViewById(R.id.b2);
        show = (Button) findViewById(R.id.b3);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e1 = (EditText) findViewById(R.id.e1);
                e2 = (EditText) findViewById(R.id.e2);
                e3 = (EditText) findViewById(R.id.e3);
                f1 = e1.getText().toString();
                l1 = e2.getText().toString();
                em = e3.getText().toString();
                db.execSQL("insert into student values('"+f1+"','"+l1+"','"+em+"')");
                Toast.makeText(getApplicationContext(),"Created",Toast.LENGTH_SHORT).show();
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });
        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MainActivity2.class);
                startActivity(i);
            }
        });
    }
}