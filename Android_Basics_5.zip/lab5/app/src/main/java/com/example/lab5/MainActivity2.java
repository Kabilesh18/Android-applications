package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    EditText e4,e5,e6;
    SQLiteDatabase db;
    Button prev,next,back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        prev = (Button) findViewById(R.id.b4);
        next = (Button) findViewById(R.id.b5);
        back = (Button) findViewById(R.id.b6);

        e4 = (EditText) findViewById(R.id.e4);
        e5 = (EditText) findViewById(R.id.e5);
        e6 = (EditText) findViewById(R.id.e6);
        db = openOrCreateDatabase("practise",MODE_PRIVATE,null);
        final Cursor c = db.rawQuery("select * from student",null);
        c.moveToFirst();
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    c.moveToPrevious();
                    e4.setText(c.getString(c.getColumnIndexOrThrow("fname")));
                    e5.setText(c.getString(c.getColumnIndexOrThrow("lname")));
                    e6.setText(c.getString(c.getColumnIndexOrThrow("email")));
                }
                catch (Exception e){
                    Toast.makeText(getApplicationContext(),"First Record",Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1 = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i1);
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    c.moveToNext();
                    e4.setText(c.getString(c.getColumnIndexOrThrow("fname")));
                    e5.setText(c.getString(c.getColumnIndexOrThrow("lname")));
                    e6.setText(c.getString(c.getColumnIndexOrThrow("email")));
                }
                catch (Exception e){
                    Toast.makeText(getApplicationContext(),"First Record",Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        });
    }
}